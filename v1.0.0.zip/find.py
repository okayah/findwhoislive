##[ IMPORTS ]##
import requests
import json
import webbrowser
import ctypes
import traceback
from os.path import dirname, join
from colorama import Fore, init
ctypes.windll.kernel32.SetConsoleTitleW('findwhoislive v1.02')
session = requests.Session()
session.cookies["CONSENT"] = "YES+cb.20210328-17-p0.en-GB+FX+"
init()

##[ LOAD FILES ]##
current_dir = dirname(__file__)
config = json.load(open(join(dirname(__file__), "./config.json")))
languages = json.load(open(join(dirname(__file__), "./assets/languages.json"), encoding="utf8"))
simple = config['simple_method']
api = config['api_method']

print(Fore.BLUE + 'Loading streamers from File...')
streamers = json.load(open(join(dirname(__file__), "./assets/streamers.json")))

if not api and not simple:
    print(Fore.LIGHTRED_EX+'Select either API or Simple method, currently none are selected.')
    quit()
elif api and simple:
    print(Fore.LIGHTRED_EX + 'Select either API or Simple method, currently both are selected.')
    quit()
if config['Authentication']['client_id'] and config['Authentication']['client_secret'] == "" and api == True:
    print(Fore.LIGHTRED_EX+'If you do not have a client_id & client_secret use simple method.')
    quit()


##[ FUNCTIONS ]##
if simple != True:
    livestreams = []

def check_site(link):
    if "youtube.com" in link:
        return "YOUTUBE"
    elif "twitch.tv" in link:
        return "TWITCH"
def check_method():
    if api:
        return "API"
    elif simple:
        return "SIMPLE"
def isLive(link, method):
    site = check_site(link)
    ##[  YOUTUBE  ]##
    if site == "YOUTUBE":
        try:
            page = session.get(link)
            if 'Started streaming' in page.content.decode('utf-8'):
                print(Fore.GREEN + f'[#] {link} is streaming.')
                livestreams.append(link)
                if config['Settings']['Open_In_Browser']:
                    webbrowser.open(link)
            else:
                print(Fore.RED + f'[X] {link} is not streaming.')
        except:
            traceback.print_exc()

    ##[  TWITCH  ]##
    elif site == "TWITCH":
        ## SIMPLE ##
        if method == 'SIMPLE':
            try:
                r = requests.get(link)
                if "isLiveBroadcast" in r.content.decode('utf-8'):
                    print(Fore.GREEN + '[#]', link, 'is live.')
                    if config['Settings']['Open_In_Browser']:
                        webbrowser.open(link)
                else:
                    print(Fore.RED + '[X]', link, 'is not live.')
            except:
                traceback.print_exc()

        ## ADVANCED ##
        elif method == 'API':
            # SEARCH ACCOUNT #
            filtered_name = link.replace("https://www.twitch.tv/", "")
            try:
                stream = requests.get('https://api.twitch.tv/helix/streams?user_login=' + filtered_name, headers=headers)
                stream_data = stream.json();

                if len(stream_data['data']) == 1:
                    # FOUND STREAM INFORMATION #
                    game = stream_data['data'][0]['game_name']
                    viewcount = str(stream_data['data'][0]['viewer_count'])
                    language = stream_data['data'][0]['language']

                    # FIND LANGUAGE #
                    for x in languages:
                        if x == language:
                            real_language = languages[x]['name']

                    # CHECK FOR CERTAIN GAME #
                    if config["Settings"]["Find_By_Game"] != "":
                        if game != config["Settings"]["Find_By_Game"]:
                            print(Fore.GREEN + f"[#] {link} is currently live, "+Fore.RED+"but not playing the game specified :(")
                            return None

                    # OUTPUT #
                    print(Fore.GREEN + f'[#] {link} is currently live. \n[#] '+Fore.LIGHTBLUE_EX+f'<{real_language}> [{game}] to {viewcount} viewer(s)');
                    livestreams.append(link)
                    if config['Settings']['Open_In_Browser']:
                        webbrowser.open(link)
                else:
                    print(Fore.RED + '[X]',link,'is not live');
            except:
                traceback.print_exc()


##[ Main Code ]##
print(Fore.LIGHTYELLOW_EX+'Selected Method: '+check_method())

if config['Authentication']['client_id'] and config['Authentication']['client_secret'] != "" and api == True:
    try:
        r = requests.post('https://id.twitch.tv/oauth2/token', {
            'client_id': config['Authentication']['client_id'],
            'client_secret': config['Authentication']['client_secret'],
            "grant_type": 'client_credentials'
        })
        headers = {
            'Client-ID': config['Authentication']['client_id'],
            'Authorization': 'Bearer ' + r.json()['access_token']
        }
    except KeyError:
        print(Fore.LIGHTRED_EX+'Please input a client_id & client_secret while using API Method.')
        quit()

for type in streamers:
    try:
        print(Fore.LIGHTWHITE_EX+'\nFinding '+type+' Streamers')
        if len(streamers[type]) != 0:
            for stream in streamers[type]:
                isLive(stream,check_method())
    except KeyError:
        print(Fore.LIGHTRED_EX+'Something went wrong!? This is most likely due to your "Find" config is setup wrong.')
        quit()

if simple != True and len(livestreams) != 0:
    print(Fore.LIGHTWHITE_EX)
    print(livestreams)
if simple == True and config['Settings']['Hide_Tips'] == False:
    print(Fore.CYAN+'\n[TIP] Want more information about your list of streamers? Take some time to get yourself a client_id & client_secret!')
if config['Settings']['Open_In_Browser'] == False and config['Settings']['Hide_Tips'] == False:
    print(Fore.CYAN + '[TIP] Want to automatically open people who are live? Enable "Open_In_Browser" in config.json!')

input(Fore.LIGHTWHITE_EX+'Press enter to close.')